# Earning Dashboard

## Features
- Exactly 5 independent Mazdoor slots
- Independent countdown timers
- Absolute `endTimeMillis` is the source of truth for running timers
- Process kill / restart restores from the absolute deadline without extending the timer
- If a timer expires while the app is closed, the slot becomes Ready
- Timer duration is persisted per slot
- Global Auto-start After Claim setting is persisted
- Claim opens the site inside the app's HTTPS-only Earning Browser
- Browser keeps website sessions/cookies inside its WebView; the app does not ask Mazdoor for passwords
- Browser supports multiple tabs, URL/search entry, back/forward, reload, HTTPS indicator, and light/dark theme
- Browser blocks top-level non-HTTPS navigation
- Mixed content is disabled and third-party cookies are disabled
- Browser includes a simple earning-focused homepage entry from the dashboard
- No CAPTCHA / anti-bot bypass or automatic security-verification handling
- Only INTERNET permission
- minSdk 24, Android 10 compatible

## Browser scope
The browser is intentionally a lightweight normal Android browser for trusted HTTPS earning pages. HTTPS encrypts the connection but does not by itself prove that a website is trustworthy; users should verify the domain before entering credentials.

## Launcher Icons
- Manifest uses `@mipmap/ic_launcher` and `@mipmap/ic_launcher_round`
- API 26+: adaptive icons (`mipmap-anydpi-v26`)
- API 24/25: non-adaptive vector icons (`mipmap-anydpi-v24`)

## Gradle Wrapper
`gradlew`, `gradlew.bat`, and `gradle-wrapper.jar` are not included.
The included GitHub Actions workflow uses a pinned Gradle 8.2 installation.

## Cloud APK Build
The repository contains `.github/workflows/build-apk.yml`.
Run it from GitHub with **Actions → Build Android APK → Run workflow**.
A successful run publishes `EarningDashboard-debug-apk` as a downloadable artifact.

## Build Status
**BUILD UNVERIFIED until GitHub Actions completes successfully.**
