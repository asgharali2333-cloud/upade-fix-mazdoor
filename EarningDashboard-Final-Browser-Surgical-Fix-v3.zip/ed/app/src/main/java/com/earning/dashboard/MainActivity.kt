package com.earning.dashboard

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {
    private val viewModel: SlotViewModel by viewModels()
    private val browserViewModel: BrowserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark by browserViewModel.darkTheme.collectAsStateWithLifecycle()
            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot(viewModel, browserViewModel)
                }
            }
        }
    }

    @Composable
    private fun AppRoot(slotsVm: SlotViewModel, browserVm: BrowserViewModel) {
        var showBrowser by remember { mutableStateOf(false) }
        val context = LocalContext.current

        if (showBrowser) {
            BrowserScreen(browserVm, onBackToDashboard = { showBrowser = false })
        } else {
            DashboardScreen(
                viewModel = slotsVm,
                onOpenBrowser = { url ->
                    browserVm.updateTabUrl(browserVm.selectedTabId.value, url)
                    showBrowser = true
                }
            )
        }
    }

    @Composable
    private fun DashboardScreen(viewModel: SlotViewModel, onOpenBrowser: (String) -> Unit) {
        val slots by viewModel.slots.collectAsStateWithLifecycle()
        val autoStart by viewModel.autoStartAfterClaim.collectAsStateWithLifecycle()
        val context = LocalContext.current
        var showSettings by remember { mutableStateOf(false) }

        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Earning Dashboard", style = MaterialTheme.typography.headlineMedium)
                    Text("5-slot Mazdoor panel", fontSize = 13.sp)
                }
                Row {
                    OutlinedButton(onClick = { onOpenBrowser("https://www.google.com/") }) { Text("Browser") }
                    Spacer(Modifier.size(6.dp))
                    OutlinedButton(onClick = { showSettings = true }) { Text("Settings") }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (slots.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
                    items(slots, key = { it.id }) { slot ->
                        SlotCard(
                            slot = slot,
                            onStart = { viewModel.startTimer(slot.id) },
                            onClaim = {
                                onOpenBrowser(slot.url)
                                viewModel.claim(slot.id)
                                Toast.makeText(
                                    context,
                                    if (autoStart) "Site opened in Earning Browser. Timer restarted." else "Site opened in Earning Browser. Slot reset.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            onReset = { viewModel.resetSlot(slot.id) },
                            onUrlChange = { newUrl ->
                                val ok = viewModel.updateUrl(slot.id, newUrl)
                                if (!ok) Toast.makeText(context, "HTTPS or HTTP URL with a valid host required", Toast.LENGTH_LONG).show()
                            },
                            onTimerChange = { minutes, seconds ->
                                val ok = viewModel.updateTimerDuration(slot.id, minutes, seconds)
                                if (!ok) Toast.makeText(context, "Invalid timer. Use 1 second to 24 hours; running slots cannot be changed.", Toast.LENGTH_LONG).show()
                            }
                        )
                    }
                }
            }
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Earning Mazdoor Settings") },
                text = {
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto-start after Claim")
                            Text("Restart the slot timer automatically after Claim.", fontSize = 12.sp, color = Color.Gray)
                        }
                        Switch(checked = autoStart, onCheckedChange = { viewModel.setAutoStartAfterClaim(it) })
                    }
                },
                confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Done") } }
            )
        }
    }

    @Composable
    private fun SlotCard(
        slot: Slot,
        onStart: () -> Unit,
        onClaim: () -> Unit,
        onReset: () -> Unit,
        onUrlChange: (String) -> Unit,
        onTimerChange: (Int, Int) -> Unit
    ) {
        var showEditDialog by remember { mutableStateOf(false) }
        var showTimerDialog by remember { mutableStateOf(false) }
        var editUrl by remember(slot.url) { mutableStateOf(slot.url) }
        var timerMinutes by remember(slot.defaultSeconds) { mutableStateOf((slot.defaultSeconds / 60).toString()) }
        var timerSeconds by remember(slot.defaultSeconds) { mutableStateOf((slot.defaultSeconds % 60).toString()) }

        Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Slot ${slot.id}", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text(slot.url, fontSize = 13.sp, color = Color.Gray, maxLines = 2)
                Spacer(Modifier.height(10.dp))
                val minutes = slot.remainingSeconds / 60
                val seconds = slot.remainingSeconds % 60
                Text(String.format("%02d:%02d", minutes, seconds), fontSize = 28.sp, color = if (slot.isReady) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurface)
                Text(
                    when { slot.isReady -> "Status: Ready"; slot.isRunning -> "Status: Waiting..."; else -> "Status: Stopped" },
                    color = if (slot.isReady) Color(0xFF2E7D32) else Color.Gray,
                    fontSize = 14.sp
                )
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = onStart, enabled = !slot.isRunning && !slot.isReady, modifier = Modifier.weight(1f)) { Text("Start") }
                    Button(onClick = onClaim, enabled = slot.isReady, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)), modifier = Modifier.weight(1f)) { Text("Claim") }
                    OutlinedButton(onClick = onReset, modifier = Modifier.weight(1f)) { Text("Reset") }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { showEditDialog = true }, modifier = Modifier.weight(1f)) { Text("Edit URL") }
                    OutlinedButton(onClick = { showTimerDialog = true }, modifier = Modifier.weight(1f)) { Text("Timer") }
                }
            }
        }

        if (showEditDialog) {
            AlertDialog(
                onDismissRequest = { showEditDialog = false },
                title = { Text("Edit URL - Slot ${slot.id}") },
                text = { OutlinedTextField(value = editUrl, onValueChange = { editUrl = it }, label = { Text("http:// or https:// URL") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri), modifier = Modifier.fillMaxWidth()) },
                confirmButton = { TextButton(onClick = { onUrlChange(editUrl); showEditDialog = false }) { Text("Save") } },
                dismissButton = { TextButton(onClick = { showEditDialog = false }) { Text("Cancel") } }
            )
        }

        if (showTimerDialog) {
            AlertDialog(
                onDismissRequest = { showTimerDialog = false },
                title = { Text("Timer - Slot ${slot.id}") },
                text = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(value = timerMinutes, onValueChange = { timerMinutes = it.filter(Char::isDigit) }, label = { Text("Minutes") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                        OutlinedTextField(value = timerSeconds, onValueChange = { timerSeconds = it.filter(Char::isDigit) }, label = { Text("Seconds") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                    }
                },
                confirmButton = { TextButton(onClick = { onTimerChange(timerMinutes.toIntOrNull() ?: -1, timerSeconds.toIntOrNull() ?: -1); showTimerDialog = false }) { Text("Save") } },
                dismissButton = { TextButton(onClick = { showTimerDialog = false }) { Text("Cancel") } }
            )
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Composable
    private fun BrowserScreen(browserVm: BrowserViewModel, onBackToDashboard: () -> Unit) {
        val tabs by browserVm.tabs.collectAsStateWithLifecycle()
        val selectedId by browserVm.selectedTabId.collectAsStateWithLifecycle()
        val dark by browserVm.darkTheme.collectAsStateWithLifecycle()
        val context = LocalContext.current
        val webViews = remember { mutableStateMapOf<Int, WebView>() }
        var address by remember(selectedId) { mutableStateOf(tabs.firstOrNull { it.id == selectedId }?.url ?: "https://www.google.com/") }
        var canBack by remember { mutableStateOf(false) }
        var canForward by remember { mutableStateOf(false) }
        var pageTitle by remember { mutableStateOf("Earning Browser") }
        var showMenu by remember { mutableStateOf(false) }

        val currentTab = tabs.firstOrNull { it.id == selectedId }

        BackHandler {
            val current = webViews[selectedId]
            when {
                current?.canGoBack() == true -> { current.goBack() }
                else -> onBackToDashboard()
            }
        }

        Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBackToDashboard) { Icon(Icons.Default.Home, "Dashboard") }
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Lock, "HTTPS-only browser") },
                    trailingIcon = { if (address.startsWith("https://", true)) Icon(Icons.Default.Security, "HTTPS") },
                    label = { Text("HTTPS website") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                )
                IconButton(onClick = {
                    val url = normalizeHttpsOrSearch(address)
                    if (url == null) Toast.makeText(context, "HTTPS only: enter a valid website address", Toast.LENGTH_SHORT).show()
                    else { address = url; webViews[selectedId]?.loadUrl(url) }
                }) { Text("Go") }
                IconButton(onClick = { showMenu = true }) { Icon(Icons.Default.MoreVert, "Menu") }
            }

            LazyRow(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(tabs, key = { it.id }) { tab ->
                    val selected = tab.id == selectedId
                    Surface(shape = RoundedCornerShape(12.dp), color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant) {
                        Row(modifier = Modifier.padding(start = 10.dp).clickable { browserVm.selectTab(tab.id) }, verticalAlignment = Alignment.CenterVertically) {
                            Text("Tab ${tab.id}", modifier = Modifier.padding(vertical = 8.dp), fontSize = 13.sp)
                            IconButton(modifier = Modifier.size(30.dp), onClick = { webViews[tab.id]?.destroy(); webViews.remove(tab.id); browserVm.closeTab(tab.id) }) { Icon(Icons.Default.Close, "Close tab", modifier = Modifier.size(16.dp)) }
                        }
                    }
                }
                item {
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                        IconButton(onClick = { browserVm.addTab() }) { Icon(Icons.Default.Add, "New tab") }
                    }
                }
            }

            Divider()

            LazyRow(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    OutlinedButton(onClick = {
                        val url = "https://faucetpay.io/"
                        address = url
                        webViews[selectedId]?.loadUrl(url)
                    }) { Text("FaucetPay") }
                }
                item {
                    OutlinedButton(onClick = {
                        val url = "https://www.google.com/"
                        address = url
                        webViews[selectedId]?.loadUrl(url)
                    }) { Text("Search") }
                }
            }

            currentTab?.let { tab ->
                val webView = webViews.getOrPut(tab.id) {
                    createWebView(context, dark,
                        onUrlChanged = { url ->
                            address = url
                            browserVm.updateTabUrl(tab.id, url)
                            canBack = webViews[tab.id]?.canGoBack() == true
                            canForward = webViews[tab.id]?.canGoForward() == true
                        },
                        onTitleChanged = { pageTitle = it },
                        onBlocked = { Toast.makeText(context, "Blocked: this browser only opens HTTPS pages", Toast.LENGTH_SHORT).show() }
                    )
                }
                key(tab.id) {
                    AndroidView(
                    factory = { webView },
                    modifier = Modifier.weight(1f),
                    update = { view ->
                        if (view.parent == null) {
                            // kept for tab switching; no-op
                        }
                    }
                    )
                }
                LaunchedEffect(tab.id) {
                    if (webView.url.isNullOrBlank()) webView.loadUrl(tab.url)
                    canBack = webView.canGoBack()
                    canForward = webView.canGoForward()
                }
            }

            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton(enabled = canBack, onClick = { webViews[selectedId]?.goBack() }) { Icon(Icons.Default.ArrowBack, "Back") }
                IconButton(enabled = canForward, onClick = { webViews[selectedId]?.goForward() }) { Icon(Icons.Default.ArrowForward, "Forward") }
                IconButton(onClick = { webViews[selectedId]?.reload() }) { Icon(Icons.Default.Refresh, "Reload") }
                Text(pageTitle.take(28), fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
                Text(if (address.startsWith("https://", true)) "🔒 HTTPS" else "⚠️", fontSize = 12.sp)
            }
        }

        if (showMenu) {
            AlertDialog(
                onDismissRequest = { showMenu = false },
                title = { Text("Browser") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("HTTPS-only earning browser", fontSize = 13.sp)
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(if (dark) Icons.Default.DarkMode else Icons.Default.LightMode, null)
                                Spacer(Modifier.size(8.dp))
                                Text(if (dark) "Dark theme" else "Light theme")
                            }
                            Switch(checked = dark, onCheckedChange = { browserVm.toggleTheme() })
                        }
                        Text("HTTP pages are blocked. HTTPS does not guarantee that a site is trustworthy; verify the domain before entering passwords.", fontSize = 12.sp, color = Color.Gray)
                    }
                },
                confirmButton = { TextButton(onClick = { showMenu = false }) { Text("Done") } }
            )
        }

        DisposableEffect(Unit) {
            onDispose {
                // Keep WebViews alive while the screen is composed; the activity owns the lifecycle.
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(
        context: Context,
        dark: Boolean,
        onUrlChanged: (String) -> Unit,
        onTitleChanged: (String) -> Unit,
        onBlocked: () -> Unit
    ): WebView {
        return WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                settings.forceDark = if (dark) WebSettings.FORCE_DARK_ON else WebSettings.FORCE_DARK_OFF
            }
            webChromeClient = object : WebChromeClient() {
                override fun onReceivedTitle(view: WebView?, title: String?) { onTitleChanged(title ?: "Earning Browser") }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val url = request.url.toString()
                    val scheme = request.url.scheme?.lowercase()
                    return if (scheme == "https") {
                        false
                    } else {
                        onBlocked()
                        true
                    }
                }

                override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                    if (url != null) onUrlChanged(url)
                }

                override fun onPageFinished(view: WebView, url: String?) {
                    if (url != null) onUrlChanged(url)
                }

                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                    return super.shouldInterceptRequest(view, request)
                }
            }
        }
    }

    private fun normalizeHttpsOrSearch(input: String): String? {
        var value = input.trim()
        if (value.isEmpty()) return null
        if (!value.contains("://")) {
            val looksLikeHost = !value.contains(" ") && value.contains(".")
            value = if (looksLikeHost) "https://$value"
            else "https://www.google.com/search?q=" + Uri.encode(value)
        }
        val uri = try { Uri.parse(value) } catch (_: Exception) { return null }
        if (uri.scheme?.lowercase() != "https") return null
        if (uri.host.isNullOrBlank()) return null
        return value
    }
}
