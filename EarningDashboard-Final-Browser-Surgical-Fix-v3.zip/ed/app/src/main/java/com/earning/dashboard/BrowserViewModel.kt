package com.earning.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class BrowserViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = BrowserPrefs(application)

    private val _tabs = MutableStateFlow(listOf(BrowserTab(1)))
    val tabs: StateFlow<List<BrowserTab>> = _tabs

    private val _selectedTabId = MutableStateFlow(1)
    val selectedTabId: StateFlow<Int> = _selectedTabId

    private val _darkTheme = MutableStateFlow(prefs.isDark())
    val darkTheme: StateFlow<Boolean> = _darkTheme

    private var nextId = 2

    fun selectTab(id: Int) {
        if (_tabs.value.any { it.id == id }) _selectedTabId.value = id
    }

    fun addTab(initialUrl: String = "https://www.google.com/") {
        val tab = BrowserTab(nextId++, initialUrl)
        _tabs.update { it + tab }
        _selectedTabId.value = tab.id
    }

    fun closeTab(id: Int) {
        val current = _tabs.value
        if (current.size == 1) {
            _tabs.value = listOf(BrowserTab(id))
            _selectedTabId.value = id
            return
        }
        val index = current.indexOfFirst { it.id == id }
        val updated = current.filterNot { it.id == id }
        _tabs.value = updated
        if (_selectedTabId.value == id) {
            _selectedTabId.value = updated.getOrNull((index - 1).coerceAtLeast(0))?.id ?: updated.first().id
        }
    }

    fun updateTabUrl(id: Int, url: String) {
        _tabs.update { tabs -> tabs.map { if (it.id == id) it.copy(url = url) else it } }
    }

    fun toggleTheme() {
        val next = !_darkTheme.value
        _darkTheme.value = next
        prefs.setDark(next)
    }
}
