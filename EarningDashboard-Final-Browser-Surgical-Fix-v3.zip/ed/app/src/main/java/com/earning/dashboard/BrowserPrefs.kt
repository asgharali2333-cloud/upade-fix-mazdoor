package com.earning.dashboard

import android.content.Context

class BrowserPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("browser_prefs", Context.MODE_PRIVATE)

    fun isDark(): Boolean = prefs.getBoolean("dark_theme", false)
    fun setDark(enabled: Boolean) = prefs.edit().putBoolean("dark_theme", enabled).apply()
}
