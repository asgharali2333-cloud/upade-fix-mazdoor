package com.earning.dashboard

data class Slot(
    val id: Int,
    val url: String,
    val remainingSeconds: Long,
    val isReady: Boolean = false,
    val isRunning: Boolean = false,
    val defaultSeconds: Long = 300L,
    val endTimeMillis: Long = 0L
)
