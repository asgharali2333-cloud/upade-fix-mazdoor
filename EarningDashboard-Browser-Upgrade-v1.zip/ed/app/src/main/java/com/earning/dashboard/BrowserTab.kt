package com.earning.dashboard

data class BrowserTab(
    val id: Int,
    val url: String = "https://www.google.com/"
)
