package com.earning.dashboard

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "slots_prefs")

class SlotRepository(private val context: Context) {

    private val autoStartAfterClaimKey = booleanPreferencesKey("auto_start_after_claim")

    private fun urlKey(id: Int) = stringPreferencesKey("url_$id")
    private fun defaultKey(id: Int) = longPreferencesKey("default_$id")
    private fun runningKey(id: Int) = longPreferencesKey("running_$id")
    private fun readyKey(id: Int) = longPreferencesKey("ready_$id")
    private fun endTimeKey(id: Int) = longPreferencesKey("end_time_$id")

    suspend fun saveSlot(slot: Slot) {
        context.dataStore.edit { prefs ->
            prefs[urlKey(slot.id)] = slot.url
            prefs[defaultKey(slot.id)] = slot.defaultSeconds
            prefs[runningKey(slot.id)] = if (slot.isRunning) 1L else 0L
            prefs[readyKey(slot.id)] = if (slot.isReady) 1L else 0L
            prefs[endTimeKey(slot.id)] = slot.endTimeMillis
        }
    }

    suspend fun getAutoStartAfterClaim(): Boolean {
        return context.dataStore.data.first()[autoStartAfterClaimKey] ?: false
    }

    suspend fun setAutoStartAfterClaim(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[autoStartAfterClaimKey] = enabled
        }
    }

    suspend fun loadSlots(): List<Slot> {
        val prefs = context.dataStore.data.first()
        val now = System.currentTimeMillis()

        return (1..5).map { id ->
            val url = prefs[urlKey(id)] ?: "https://example.com/earn$id"
            val defaultSec = prefs[defaultKey(id)] ?: when (id) {
                1 -> 30L
                2 -> 45L
                3 -> 60L
                4 -> 90L
                else -> 120L
            }
            val savedEndTime = prefs[endTimeKey(id)] ?: 0L
            val wasRunning = (prefs[runningKey(id)] ?: 0L) == 1L
            val wasReady = (prefs[readyKey(id)] ?: 0L) == 1L

            val (remaining, isRunning, isReady, endTime) = when {
                wasReady -> {
                    Quadruple(0L, false, true, 0L)
                }
                wasRunning && savedEndTime > 0L -> {
                    val rem = ((savedEndTime - now) / 1000L).coerceAtLeast(0L)
                    if (rem > 0L) {
                        Quadruple(rem, true, false, savedEndTime)
                    } else {
                        Quadruple(0L, false, true, 0L)
                    }
                }
                else -> {
                    Quadruple(defaultSec, false, false, 0L)
                }
            }

            Slot(
                id = id,
                url = url,
                remainingSeconds = remaining,
                isReady = isReady,
                isRunning = isRunning,
                defaultSeconds = defaultSec,
                endTimeMillis = endTime
            )
        }
    }
}

private data class Quadruple<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)
