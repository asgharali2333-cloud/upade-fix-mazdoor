package com.earning.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

class BrowserViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = BrowserPrefs(application)

    private val _tabs = MutableStateFlow(listOf(BrowserTab(1)))
    val tabs: StateFlow<List<BrowserTab>> = _tabs

    private val _selectedTabId = MutableStateFlow(1)
    val selectedTabId: StateFlow<Int> = _selectedTabId

    private val _darkTheme = MutableStateFlow(prefs.isDark())
    val darkTheme: StateFlow<Boolean> = _darkTheme

    private val _bookmarks = MutableStateFlow(prefs.loadBookmarks())
    val bookmarks: StateFlow<List<String>> = _bookmarks

    private val _history = MutableStateFlow(prefs.loadHistory())
    val history: StateFlow<List<String>> = _history

    private var nextId = 2

    fun selectTab(id: Int) { if (_tabs.value.any { it.id == id }) _selectedTabId.value = id }

    fun addTab(initialUrl: String = "https://www.google.com/") {
        val tab = BrowserTab(nextId++, initialUrl)
        _tabs.update { it + tab }
        _selectedTabId.value = tab.id
    }

    fun closeTab(id: Int) {
        val current = _tabs.value
        if (current.size == 1) {
            _tabs.value = listOf(BrowserTab(id))
            _selectedTabId.value = id
            return
        }
        val index = current.indexOfFirst { it.id == id }
        val updated = current.filterNot { it.id == id }
        _tabs.value = updated
        if (_selectedTabId.value == id) {
            _selectedTabId.value = updated.getOrNull((index - 1).coerceAtLeast(0))?.id ?: updated.first().id
        }
    }

    fun updateTabUrl(id: Int, url: String) {
        _tabs.update { tabs -> tabs.map { if (it.id == id) it.copy(url = url) else it } }
    }

    fun addHistory(url: String) {
        if (!url.startsWith("https://", true)) return
        val updated = listOf(url) + _history.value.filterNot { it == url }
        _history.value = updated.take(100)
        prefs.saveHistory(_history.value)
    }

    fun toggleBookmark(url: String): Boolean {
        if (url.isBlank() || !url.startsWith("https://", true)) return false
        val exists = _bookmarks.value.any { it == url }
        val updated = if (exists) _bookmarks.value.filterNot { it == url } else listOf(url) + _bookmarks.value
        _bookmarks.value = updated.take(100)
        prefs.saveBookmarks(_bookmarks.value)
        return !exists
    }

    fun isBookmarked(url: String): Boolean = _bookmarks.value.any { it == url }

    fun clearHistory() {
        _history.value = emptyList()
        prefs.saveHistory(emptyList())
    }

    fun toggleTheme() {
        val next = !_darkTheme.value
        _darkTheme.value = next
        prefs.setDark(next)
    }
}
