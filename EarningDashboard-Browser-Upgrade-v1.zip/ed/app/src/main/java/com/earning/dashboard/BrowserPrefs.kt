package com.earning.dashboard

import android.content.Context
import org.json.JSONArray

class BrowserPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("browser_prefs", Context.MODE_PRIVATE)

    fun isDark(): Boolean = prefs.getBoolean("dark_theme", false)
    fun setDark(enabled: Boolean) = prefs.edit().putBoolean("dark_theme", enabled).apply()

    fun loadBookmarks(): List<String> = readList("bookmarks")
    fun saveBookmarks(items: List<String>) = writeList("bookmarks", items)

    fun loadHistory(): List<String> = readList("history")
    fun saveHistory(items: List<String>) = writeList("history", items)

    private fun readList(key: String): List<String> {
        val raw = prefs.getString(key, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { arr.getString(it) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun writeList(key: String, items: List<String>) {
        val arr = JSONArray()
        items.forEach { arr.put(it) }
        prefs.edit().putString(key, arr.toString()).apply()
    }
}
