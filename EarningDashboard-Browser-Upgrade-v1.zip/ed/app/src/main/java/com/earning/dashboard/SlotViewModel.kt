package com.earning.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SlotViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SlotRepository(application)

    private val _slots = MutableStateFlow<List<Slot>>(emptyList())
    val slots: StateFlow<List<Slot>> = _slots

    private val _autoStartAfterClaim = MutableStateFlow(false)
    val autoStartAfterClaim: StateFlow<Boolean> = _autoStartAfterClaim

    private val jobs = mutableMapOf<Int, Job>()

    init {
        viewModelScope.launch {
            _autoStartAfterClaim.value = repository.getAutoStartAfterClaim()
            val loaded = repository.loadSlots()
            _slots.value = loaded

            loaded.forEach { slot ->
                if (slot.isRunning && slot.remainingSeconds > 0 && slot.endTimeMillis > 0L) {
                    startTimerInternal(
                        slotId = slot.id,
                        fromSeconds = slot.remainingSeconds,
                        existingEndTimeMillis = slot.endTimeMillis
                    )
                }
            }
        }
    }

    private fun startTimerInternal(
        slotId: Int,
        fromSeconds: Long,
        existingEndTimeMillis: Long = 0L
    ) {
        jobs[slotId]?.cancel()

        val endTime = existingEndTimeMillis.takeIf { it > 0L }
            ?: (System.currentTimeMillis() + fromSeconds * 1000L)
        val initialRemaining = ((endTime - System.currentTimeMillis()) / 1000L)
            .coerceAtLeast(0L)

        if (initialRemaining <= 0L) {
            viewModelScope.launch {
                val current = _slots.value.find { it.id == slotId } ?: return@launch
                val ready = current.copy(
                    isRunning = false,
                    isReady = true,
                    remainingSeconds = 0L,
                    endTimeMillis = 0L
                )
                _slots.update { list ->
                    list.map { if (it.id == slotId) ready else it }
                }
                repository.saveSlot(ready)
            }
            return
        }

        viewModelScope.launch {
            val current = _slots.value.find { it.id == slotId } ?: return@launch
            val updated = current.copy(
                isRunning = true,
                isReady = false,
                remainingSeconds = initialRemaining,
                endTimeMillis = endTime
            )
            _slots.update { list ->
                list.map { if (it.id == slotId) updated else it }
            }
            repository.saveSlot(updated)
        }

        jobs[slotId] = viewModelScope.launch {
            var remaining = initialRemaining
            while (remaining > 0) {
                delay(1000)
                val now = System.currentTimeMillis()
                remaining = ((endTime - now) / 1000L).coerceAtLeast(0L)

                _slots.update { list ->
                    list.map { slot ->
                        if (slot.id == slotId) {
                            slot.copy(
                                remainingSeconds = remaining,
                                isReady = remaining <= 0,
                                isRunning = remaining > 0,
                                endTimeMillis = if (remaining > 0) endTime else 0L
                            )
                        } else slot
                    }
                }

                if (remaining % 5 == 0L || remaining <= 0) {
                    _slots.value.find { it.id == slotId }?.let { repository.saveSlot(it) }
                }
            }

            _slots.value.find { it.id == slotId }?.let { finished ->
                val done = finished.copy(
                    remainingSeconds = 0,
                    isReady = true,
                    isRunning = false,
                    endTimeMillis = 0L
                )
                _slots.update { list ->
                    list.map { if (it.id == slotId) done else it }
                }
                repository.saveSlot(done)
            }
        }
    }

    fun startTimer(slotId: Int) {
        val slot = _slots.value.find { it.id == slotId } ?: return
        if (slot.isRunning || slot.isReady) return

        val startFrom = if (slot.remainingSeconds > 0) slot.remainingSeconds else slot.defaultSeconds
        startTimerInternal(slotId, startFrom, 0L)
    }

    fun claim(slotId: Int) {
        val slot = _slots.value.find { it.id == slotId } ?: return
        if (!slot.isReady) return

        jobs[slotId]?.cancel()

        val resetSlot = slot.copy(
            remainingSeconds = slot.defaultSeconds,
            isReady = false,
            isRunning = false,
            endTimeMillis = 0L
        )

        _slots.update { list ->
            list.map { if (it.id == slotId) resetSlot else it }
        }

        viewModelScope.launch {
            repository.saveSlot(resetSlot)
            if (_autoStartAfterClaim.value) {
                startTimerInternal(slotId, resetSlot.defaultSeconds, 0L)
            }
        }
    }

    fun setAutoStartAfterClaim(enabled: Boolean) {
        _autoStartAfterClaim.value = enabled
        viewModelScope.launch { repository.setAutoStartAfterClaim(enabled) }
    }

    fun updateTimerDuration(slotId: Int, minutes: Int, seconds: Int): Boolean {
        if (minutes < 0 || seconds !in 0..59) return false
        val totalSeconds = minutes.toLong() * 60L + seconds.toLong()
        if (totalSeconds <= 0L || totalSeconds > 24L * 60L * 60L) return false

        val slot = _slots.value.find { it.id == slotId } ?: return false
        if (slot.isRunning) return false

        val updated = slot.copy(
            defaultSeconds = totalSeconds,
            remainingSeconds = if (slot.isReady) 0L else totalSeconds
        )

        _slots.update { list ->
            list.map { if (it.id == slotId) updated else it }
        }

        viewModelScope.launch { repository.saveSlot(updated) }
        return true
    }

    fun resetSlot(slotId: Int) {
        jobs[slotId]?.cancel()
        val slot = _slots.value.find { it.id == slotId } ?: return
        val reset = slot.copy(
            remainingSeconds = slot.defaultSeconds,
            isReady = false,
            isRunning = false,
            endTimeMillis = 0L
        )

        _slots.update { list -> list.map { if (it.id == slotId) reset else it } }
        viewModelScope.launch { repository.saveSlot(reset) }
    }

    fun updateUrl(slotId: Int, newUrl: String): Boolean {
        val cleaned = newUrl.trim()
        if (cleaned.isEmpty()) return false

        val uri = try { android.net.Uri.parse(cleaned) } catch (e: Exception) { return false }
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") return false
        if (uri.host.isNullOrBlank()) return false

        _slots.update { list -> list.map { if (it.id == slotId) it.copy(url = cleaned) else it } }
        viewModelScope.launch {
            _slots.value.find { it.id == slotId }?.let { repository.saveSlot(it) }
        }
        return true
    }
}
