package com.earning.dashboard

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.graphics.Bitmap
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {
    private val viewModel: SlotViewModel by viewModels()
    private val browserViewModel: BrowserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark by browserViewModel.darkTheme.collectAsStateWithLifecycle()
            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot(viewModel, browserViewModel)
                }
            }
        }
    }

    @Composable
    private fun AppRoot(slotsVm: SlotViewModel, browserVm: BrowserViewModel) {
        var showBrowser by remember { mutableStateOf(false) }
        val context = LocalContext.current

        if (showBrowser) {
            BrowserScreen(browserVm, slotsVm, onBackToDashboard = { showBrowser = false })
        } else {
            DashboardScreen(
                viewModel = slotsVm,
                onOpenBrowser = { url ->
                    browserVm.updateTabUrl(browserVm.selectedTabId.value, url)
                    showBrowser = true
                }
            )
        }
    }

    @Composable
    private fun DashboardScreen(viewModel: SlotViewModel, onOpenBrowser: (String) -> Unit) {
        val slots by viewModel.slots.collectAsStateWithLifecycle()
        val autoStart by viewModel.autoStartAfterClaim.collectAsStateWithLifecycle()
        val context = LocalContext.current
        var showSettings by remember { mutableStateOf(false) }

        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Earning Dashboard", style = MaterialTheme.typography.headlineMedium)
                    Text("5-slot Mazdoor panel", fontSize = 13.sp)
                }
                Row {
                    OutlinedButton(onClick = { onOpenBrowser("https://www.google.com/") }) { Text("Browser") }
                    Spacer(Modifier.size(6.dp))
                    OutlinedButton(onClick = { showSettings = true }) { Text("Settings") }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (slots.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
                    items(slots, key = { it.id }) { slot ->
                        SlotCard(
                            slot = slot,
                            onStart = { viewModel.startTimer(slot.id) },
                            onClaim = {
                                onOpenBrowser(slot.url)
                                viewModel.claim(slot.id)
                                Toast.makeText(
                                    context,
                                    if (autoStart) "Site opened in Earning Browser. Timer restarted." else "Site opened in Earning Browser. Slot reset.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            onReset = { viewModel.resetSlot(slot.id) },
                            onUrlChange = { newUrl ->
                                val ok = viewModel.updateUrl(slot.id, newUrl)
                                if (!ok) Toast.makeText(context, "HTTPS or HTTP URL with a valid host required", Toast.LENGTH_LONG).show()
                            },
                            onTimerChange = { minutes, seconds ->
                                val ok = viewModel.updateTimerDuration(slot.id, minutes, seconds)
                                if (!ok) Toast.makeText(context, "Invalid timer. Use 1 second to 24 hours; running slots cannot be changed.", Toast.LENGTH_LONG).show()
                            }
                        )
                    }
                }
            }
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Earning Mazdoor Settings") },
                text = {
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto-start after Claim")
                            Text("Restart the slot timer automatically after Claim.", fontSize = 12.sp, color = Color.Gray)
                        }
                        Switch(checked = autoStart, onCheckedChange = { viewModel.setAutoStartAfterClaim(it) })
                    }
                },
                confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Done") } }
            )
        }
    }

    @Composable
    private fun SlotCard(
        slot: Slot,
        onStart: () -> Unit,
        onClaim: () -> Unit,
        onReset: () -> Unit,
        onUrlChange: (String) -> Unit,
        onTimerChange: (Int, Int) -> Unit
    ) {
        var showEditDialog by remember { mutableStateOf(false) }
        var showTimerDialog by remember { mutableStateOf(false) }
        var editUrl by remember(slot.url) { mutableStateOf(slot.url) }
        var timerMinutes by remember(slot.defaultSeconds) { mutableStateOf((slot.defaultSeconds / 60).toString()) }
        var timerSeconds by remember(slot.defaultSeconds) { mutableStateOf((slot.defaultSeconds % 60).toString()) }

        Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Slot ${slot.id}", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text(slot.url, fontSize = 13.sp, color = Color.Gray, maxLines = 2)
                Spacer(Modifier.height(10.dp))
                val minutes = slot.remainingSeconds / 60
                val seconds = slot.remainingSeconds % 60
                Text(String.format("%02d:%02d", minutes, seconds), fontSize = 28.sp, color = if (slot.isReady) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurface)
                Text(
                    when { slot.isReady -> "Status: Ready"; slot.isRunning -> "Status: Waiting..."; else -> "Status: Stopped" },
                    color = if (slot.isReady) Color(0xFF2E7D32) else Color.Gray,
                    fontSize = 14.sp
                )
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = onStart, enabled = !slot.isRunning && !slot.isReady, modifier = Modifier.weight(1f)) { Text("Start") }
                    Button(onClick = onClaim, enabled = slot.isReady, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)), modifier = Modifier.weight(1f)) { Text("Claim") }
                    OutlinedButton(onClick = onReset, modifier = Modifier.weight(1f)) { Text("Reset") }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { showEditDialog = true }, modifier = Modifier.weight(1f)) { Text("Edit URL") }
                    OutlinedButton(onClick = { showTimerDialog = true }, modifier = Modifier.weight(1f)) { Text("Timer") }
                }
            }
        }

        if (showEditDialog) {
            AlertDialog(
                onDismissRequest = { showEditDialog = false },
                title = { Text("Edit URL - Slot ${slot.id}") },
                text = { OutlinedTextField(value = editUrl, onValueChange = { editUrl = it }, label = { Text("http:// or https:// URL") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri), modifier = Modifier.fillMaxWidth()) },
                confirmButton = { TextButton(onClick = { onUrlChange(editUrl); showEditDialog = false }) { Text("Save") } },
                dismissButton = { TextButton(onClick = { showEditDialog = false }) { Text("Cancel") } }
            )
        }

        if (showTimerDialog) {
            AlertDialog(
                onDismissRequest = { showTimerDialog = false },
                title = { Text("Timer - Slot ${slot.id}") },
                text = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(value = timerMinutes, onValueChange = { timerMinutes = it.filter(Char::isDigit) }, label = { Text("Minutes") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                        OutlinedTextField(value = timerSeconds, onValueChange = { timerSeconds = it.filter(Char::isDigit) }, label = { Text("Seconds") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                    }
                },
                confirmButton = { TextButton(onClick = { onTimerChange(timerMinutes.toIntOrNull() ?: -1, timerSeconds.toIntOrNull() ?: -1); showTimerDialog = false }) { Text("Save") } },
                dismissButton = { TextButton(onClick = { showTimerDialog = false }) { Text("Cancel") } }
            )
        }
    }


    @SuppressLint("SetJavaScriptEnabled")
    @Composable
    private fun BrowserScreen(
        browserVm: BrowserViewModel,
        slotsVm: SlotViewModel,
        onBackToDashboard: () -> Unit
    ) {
        val tabs by browserVm.tabs.collectAsStateWithLifecycle()
        val selectedId by browserVm.selectedTabId.collectAsStateWithLifecycle()
        val dark by browserVm.darkTheme.collectAsStateWithLifecycle()
        val bookmarks by browserVm.bookmarks.collectAsStateWithLifecycle()
        val history by browserVm.history.collectAsStateWithLifecycle()
        val slots by slotsVm.slots.collectAsStateWithLifecycle()
        val autoStart by slotsVm.autoStartAfterClaim.collectAsStateWithLifecycle()
        val context = LocalContext.current
        val webViews = remember { mutableStateMapOf<Int, WebView>() }
        var address by remember(selectedId) { mutableStateOf(tabs.firstOrNull { it.id == selectedId }?.url ?: "https://www.google.com/") }
        var canBack by remember { mutableStateOf(false) }
        var canForward by remember { mutableStateOf(false) }
        var pageTitle by remember { mutableStateOf("Earning Browser") }
        var showMenu by remember { mutableStateOf(false) }
        var showBookmarks by remember { mutableStateOf(false) }
        var showHistory by remember { mutableStateOf(false) }
        var showBrowserSettings by remember { mutableStateOf(false) }
        var showTraceResult by remember { mutableStateOf(false) }
        var traceMessage by remember { mutableStateOf("") }
        var traceSeconds by remember { mutableStateOf<Long?>(null) }
        var traceSlotId by remember { mutableStateOf<Int?>(null) }

        val currentTab = tabs.firstOrNull { it.id == selectedId }
        val currentUrl = webViews[selectedId]?.url ?: address
        val currentBookmarked = browserVm.isBookmarked(currentUrl)

        BackHandler {
            val current = webViews[selectedId]
            if (current?.canGoBack() == true) current.goBack() else onBackToDashboard()
        }

        fun loadUrl(raw: String) {
            val url = normalizeHttpsOrSearch(raw)
            if (url == null) {
                Toast.makeText(context, "HTTPS only: enter a valid website or search", Toast.LENGTH_SHORT).show()
                return
            }
            address = url
            webViews[selectedId]?.loadUrl(url)
        }

        Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            // Browser toolbar
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackToDashboard) { Icon(Icons.Default.Home, "Dashboard") }
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Lock, "HTTPS") },
                    trailingIcon = { if (address.startsWith("https://", true)) Icon(Icons.Default.Security, "Secure transport") },
                    label = { Text("Search or enter address") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                )
                TextButton(onClick = { loadUrl(address) }) { Text("Go") }
                IconButton(onClick = { showMenu = true }) { Icon(Icons.Default.MoreVert, "Browser menu") }
            }

            // Tabs
            LazyRow(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(tabs, key = { it.id }) { tab ->
                    val selected = tab.id == selectedId
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            modifier = Modifier.padding(start = 10.dp).clickable { browserVm.selectTab(tab.id) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Tab ${tab.id}", modifier = Modifier.padding(vertical = 8.dp), fontSize = 13.sp)
                            IconButton(modifier = Modifier.size(30.dp), onClick = {
                                webViews[tab.id]?.destroy()
                                webViews.remove(tab.id)
                                browserVm.closeTab(tab.id)
                            }) { Icon(Icons.Default.Close, "Close tab", modifier = Modifier.size(16.dp)) }
                        }
                    }
                }
                item {
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                        IconButton(onClick = { browserVm.addTab() }) { Icon(Icons.Default.Add, "New tab") }
                    }
                }
            }

            // Quick browser actions
            LazyRow(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item { OutlinedButton(onClick = { loadUrl("https://www.google.com/") }) { Text("Google") } }
                item { OutlinedButton(onClick = { loadUrl("https://faucetpay.io/") }) { Text("FaucetPay") } }
                item {
                    OutlinedButton(onClick = {
                        val added = browserVm.toggleBookmark(currentUrl)
                        Toast.makeText(context, if (added) "Bookmarked" else "Bookmark removed", Toast.LENGTH_SHORT).show()
                    }) { Text(if (currentBookmarked) "★ Saved" else "☆ Bookmark") }
                }
                item {
                    OutlinedButton(enabled = slots.isNotEmpty(), onClick = {
                        val slot = slots.firstOrNull { it.id == traceSlotId } ?: slots.firstOrNull()
                        traceSlotId = slot?.id
                        traceSeconds = null
                        traceMessage = "Scanning visible page text…"
                        showTraceResult = true
                        webViews[selectedId]?.let { view ->
                            traceSiteTimer(view) { seconds, message ->
                                traceSeconds = seconds
                                traceMessage = message
                            }
                        }
                    }) { Text("Trace Site Timer") }
                }
            }

            // Compact 5-slot earning panel inside the browser
            if (slots.isNotEmpty()) {
                LazyRow(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(slots, key = { it.id }) { slot ->
                        val mins = slot.remainingSeconds / 60
                        val secs = slot.remainingSeconds % 60
                        Card(modifier = Modifier.size(width = 122.dp, height = 86.dp), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("S${slot.id}", style = MaterialTheme.typography.labelLarge)
                                Text(String.format("%02d:%02d", mins, secs), fontSize = 18.sp)
                                Text(
                                    when { slot.isReady -> "Ready"; slot.isRunning -> "Waiting"; else -> "Stopped" },
                                    fontSize = 11.sp,
                                    color = if (slot.isReady) Color(0xFF2E7D32) else Color.Gray
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    TextButton(enabled = !slot.isRunning && !slot.isReady, onClick = { slotsVm.startTimer(slot.id) }) { Text("Start", fontSize = 10.sp) }
                                    TextButton(enabled = slot.isReady, onClick = { loadUrl(slot.url); slotsVm.claim(slot.id) }) { Text("Claim", fontSize = 10.sp) }
                                }
                            }
                        }
                    }
                }
            }

            Divider()

            currentTab?.let { tab ->
                val webView = webViews.getOrPut(tab.id) {
                    createWebView(
                        context = context,
                        dark = dark,
                        onUrlChanged = { url ->
                            address = url
                            browserVm.updateTabUrl(tab.id, url)
                            browserVm.addHistory(url)
                            canBack = webViews[tab.id]?.canGoBack() == true
                            canForward = webViews[tab.id]?.canGoForward() == true
                        },
                        onTitleChanged = { pageTitle = it },
                        onBlocked = { Toast.makeText(context, "Blocked: this browser only opens HTTPS pages", Toast.LENGTH_SHORT).show() },
                        onDownload = { url, userAgent, contentDisposition, mimeType ->
                            enqueueDownload(context, url, userAgent, contentDisposition, mimeType)
                        }
                    )
                }
                key(tab.id) {
                    AndroidView(factory = { webView }, modifier = Modifier.weight(1f))
                }
                LaunchedEffect(tab.id) {
                    if (webView.url.isNullOrBlank()) webView.loadUrl(tab.url)
                    canBack = webView.canGoBack()
                    canForward = webView.canGoForward()
                }
            }

            // Navigation/status bar
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(enabled = canBack, onClick = { webViews[selectedId]?.goBack() }) { Icon(Icons.Default.ArrowBack, "Back") }
                IconButton(enabled = canForward, onClick = { webViews[selectedId]?.goForward() }) { Icon(Icons.Default.ArrowForward, "Forward") }
                IconButton(onClick = { webViews[selectedId]?.reload() }) { Icon(Icons.Default.Refresh, "Reload") }
                Text(pageTitle.take(24), fontSize = 11.sp, maxLines = 1, modifier = Modifier.weight(1f).padding(horizontal = 4.dp))
                Text(if (currentUrl.startsWith("https://", true)) "🔒 HTTPS" else "⚠️", fontSize = 11.sp)
            }
        }

        if (showMenu) {
            AlertDialog(
                onDismissRequest = { showMenu = false },
                title = { Text("Browser menu") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Real WebView browser controls", fontSize = 13.sp, color = Color.Gray)
                        TextButton(onClick = { showMenu = false; showBookmarks = true }) { Text("🔖 Bookmarks (${bookmarks.size})") }
                        TextButton(onClick = { showMenu = false; showHistory = true }) { Text("🕘 History (${history.size})") }
                        TextButton(onClick = {
                            showMenu = false
                            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                            Toast.makeText(context, "Downloads are handled by Android Download Manager", Toast.LENGTH_SHORT).show()
                            try { context.startActivity(android.content.Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) } catch (_: Exception) { }
                        }) { Text("⬇ Downloads") }
                        TextButton(onClick = { showMenu = false; showBrowserSettings = true }) { Text("⚙ Browser settings") }
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(if (dark) "Dark theme" else "Light theme")
                            Switch(checked = dark, onCheckedChange = { browserVm.toggleTheme() })
                        }
                        Text("HTTPS-only navigation. HTTPS means encrypted transport, not automatic trust.", fontSize = 12.sp, color = Color.Gray)
                    }
                },
                confirmButton = { TextButton(onClick = { showMenu = false }) { Text("Done") } }
            )
        }

        if (showBookmarks) {
            AlertDialog(
                onDismissRequest = { showBookmarks = false },
                title = { Text("Bookmarks") },
                text = {
                    if (bookmarks.isEmpty()) Text("No bookmarks yet.")
                    else LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(bookmarks) { url ->
                            TextButton(onClick = { address = url; loadUrl(url); showBookmarks = false }) { Text(url, maxLines = 2) }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showBookmarks = false }) { Text("Done") } }
            )
        }

        if (showHistory) {
            AlertDialog(
                onDismissRequest = { showHistory = false },
                title = { Text("History") },
                text = {
                    Column {
                        if (history.isEmpty()) Text("No history yet.")
                        else LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            items(history) { url ->
                                TextButton(onClick = { address = url; loadUrl(url); showHistory = false }) { Text(url, maxLines = 2) }
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { browserVm.clearHistory(); showHistory = false }) { Text("Clear") } },
                dismissButton = { TextButton(onClick = { showHistory = false }) { Text("Done") } }
            )
        }

        if (showBrowserSettings) {
            AlertDialog(
                onDismissRequest = { showBrowserSettings = false },
                title = { Text("Browser settings") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Transport: HTTPS only")
                        Text("JavaScript: enabled for modern sites")
                        Text("Third-party cookies: disabled")
                        Text("Mixed content: blocked")
                        Text("Downloads: Android Download Manager")
                        Text("History/bookmarks: stored locally on this device")
                        Text("Auto-start after Claim: ${if (autoStart) "ON" else "OFF"}")
                    }
                },
                confirmButton = { TextButton(onClick = { showBrowserSettings = false }) { Text("Done") } }
            )
        }

        if (showTraceResult) {
            AlertDialog(
                onDismissRequest = { showTraceResult = false },
                title = { Text("Trace Site Timer") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(traceMessage)
                        traceSeconds?.let { Text("Detected: ${formatDuration(it)}") }
                        Text("This reads visible page text/DOM. Hidden, image/canvas, or server-only timers may not be detectable.", fontSize = 12.sp, color = Color.Gray)
                    }
                },
                confirmButton = {
                    TextButton(
                        enabled = traceSeconds != null && traceSlotId != null,
                        onClick = {
                            val sec = traceSeconds
                            val id = traceSlotId
                            if (sec != null && id != null) {
                                val mins = (sec / 60).toInt()
                                val rem = (sec % 60).toInt()
                                if (slotsVm.updateTimerDuration(id, mins, rem)) {
                                    Toast.makeText(context, "Slot $id timer set to ${formatDuration(sec)}", Toast.LENGTH_SHORT).show()
                                }
                            }
                            showTraceResult = false
                        }
                    ) { Text("Use Timer") }
                },
                dismissButton = { TextButton(onClick = { showTraceResult = false }) { Text("Close") } }
            )
        }

        DisposableEffect(Unit) {
            onDispose { /* WebViews remain managed by this Activity instance. */ }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(
        context: Context,
        dark: Boolean,
        onUrlChanged: (String) -> Unit,
        onTitleChanged: (String) -> Unit,
        onBlocked: () -> Unit,
        onDownload: (String, String?, String?, String?) -> Unit
    ): WebView {
        return WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                settings.forceDark = if (dark) WebSettings.FORCE_DARK_ON else WebSettings.FORCE_DARK_OFF
            }
            setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                if (url.startsWith("https://", true)) onDownload(url, userAgent, contentDisposition, mimeType)
                else onBlocked()
            }
            webChromeClient = object : WebChromeClient() {
                override fun onReceivedTitle(view: WebView?, title: String?) { onTitleChanged(title ?: "Earning Browser") }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val scheme = request.url.scheme?.lowercase()
                    return if (scheme == "https") false else { onBlocked(); true }
                }
                override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) { if (url != null) onUrlChanged(url) }
                override fun onPageFinished(view: WebView, url: String?) { if (url != null) onUrlChanged(url) }
            }
        }
    }

    private fun enqueueDownload(context: Context, url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
                .setMimeType(mimeType ?: "application/octet-stream")
                .addRequestHeader("User-Agent", userAgent ?: WebSettings.getDefaultUserAgent(context))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setTitle("Earning Browser download")
                .setDescription(url)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
            android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType)?.let { request.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, it) }
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)
            Toast.makeText(context, "Download started", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Download failed: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun traceSiteTimer(webView: WebView, callback: (Long?, String) -> Unit) {
        val js = """
            (function(){
              const text=(document.body?.innerText||'').replace(/\\s+/g,' ').trim();
              const words=['claim','next','available','wait','waiting','retry','again','countdown'];
              const candidates=[];
              const re=/\\b(\\d{1,2}):(\\d{2})(?::(\\d{2}))?\\b/g;
              let m;
              while((m=re.exec(text))){
                const raw=m[0], h=m[3]?parseInt(m[1]):0, min=m[3]?parseInt(m[2]):parseInt(m[1]), sec=parseInt(m[3]||m[2]);
                const total=m[3]?h*3600+min*60+sec:min*60+sec;
                const ctx=text.slice(Math.max(0,m.index-90),Math.min(text.length,m.index+raw.length+90)).toLowerCase();
                let score=0; words.forEach(w=>{if(ctx.includes(w))score+=3});
                if(total>0&&total<=86400)candidates.push({total,score,raw});
              }
              const secRe=/\\b(\\d{1,5})\\s*(seconds?|secs?)\\b/gi;
              while((m=secRe.exec(text))){
                const total=parseInt(m[1]); const ctx=text.slice(Math.max(0,m.index-90),Math.min(text.length,m.index+m[0].length+90)).toLowerCase();
                let score=0; words.forEach(w=>{if(ctx.includes(w))score+=3});
                if(total>0&&total<=86400)candidates.push({total,score,raw:m[0]});
              }
              candidates.sort((a,b)=>b.score-a.score||a.total-b.total);
              return candidates.length?JSON.stringify(candidates[0]):'';
            })()
        """.trimIndent()
        webView.evaluateJavascript(js) { raw ->
            val value = raw?.trim()?.removePrefix("\"")?.removeSuffix("\"")?.replace("\\\"", "\"") ?: ""
            try {
                val obj = org.json.JSONObject(value)
                val seconds = obj.optLong("total", 0L).takeIf { it > 0L }
                if (seconds != null) callback(seconds, "Visible countdown detected") else callback(null, "Timer not detected on this page")
            } catch (_: Exception) {
                callback(null, "Timer not detected on this page")
            }
        }
    }

    private fun formatDuration(seconds: Long): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) String.format("%02d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
    }

    private fun normalizeHttpsOrSearch(input: String): String? {
        var value = input.trim()
        if (value.isEmpty()) return null
        if (!value.contains("://")) {
            val looksLikeHost = !value.contains(" ") && value.contains(".")
            value = if (looksLikeHost) "https://$value" else "https://www.google.com/search?q=" + Uri.encode(value)
        }
        val uri = try { Uri.parse(value) } catch (_: Exception) { return null }
        if (uri.scheme?.lowercase() != "https") return null
        if (uri.host.isNullOrBlank()) return null
        return value
    }
}
